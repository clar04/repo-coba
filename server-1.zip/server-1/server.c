#include <stdio.h>
#include <stdlib.h>
#include <libssh/libssh.h>
#include <libssh/sftp.h>
#include <fcntl.h> // Include the fcntl.h header

int main() {
    ssh_session my_ssh_session;
    sftp_session my_sftp_session;
    sftp_file my_sftp_file;
    char *sftp_filename = "/path/to/remote/file";
    char *local_filename = "/path/to/local/file";

    my_ssh_session = ssh_new();
    if (my_ssh_session == NULL) {
        fprintf(stderr, "Error creating SSH session.\n");
        return 1;
    }

    // Set hostname and authentication options
    ssh_options_set(my_ssh_session, SSH_OPTIONS_HOST, "clar");
    ssh_options_set(my_ssh_session, SSH_OPTIONS_USER, "clar");

    if (ssh_connect(my_ssh_session) != SSH_OK) {
        fprintf(stderr, "Error connecting to SSH server: %s\n", ssh_get_error(my_ssh_session));
        return 1;
    }

    if (ssh_userauth_password(my_ssh_session, NULL, "2204") != SSH_AUTH_SUCCESS) {
        fprintf(stderr, "Error authenticating with password.\n");
        return 1;
    }

    // Initialize SFTP session
    my_sftp_session = sftp_new(my_ssh_session);
    if (my_sftp_session == NULL) {
        fprintf(stderr, "Error creating SFTP session.\n");
        return 1;
    }

    if (sftp_init(my_sftp_session) != SSH_OK) {
        fprintf(stderr, "Error initializing SFTP session.\n");
        return 1;
    }

    // Open remote file for reading
    my_sftp_file = sftp_open(my_sftp_session, sftp_filename, 0, 0); // Use 0 for no specific flags
    if (my_sftp_file == NULL) {
        fprintf(stderr, "Error opening remote file.\n");
        return 1;
    }

    // Create local file for writing
    FILE *local_file = fopen(local_filename, "w");
    if (local_file == NULL) {
        fprintf(stderr, "Error creating local file.\n");
        return 1;
    }

    // Download file from SFTP to local file
    char buffer[8192];
    size_t nbytes;
    while ((nbytes = sftp_read(my_sftp_file, buffer, sizeof(buffer))) > 0) {
        fwrite(buffer, 1, nbytes, local_file);
    }

    // Clean up and close connections
    fclose(local_file);
    sftp_close(my_sftp_file);
    sftp_free(my_sftp_session);
    ssh_disconnect(my_ssh_session);
    ssh_free(my_ssh_session);

    return 0;
}

