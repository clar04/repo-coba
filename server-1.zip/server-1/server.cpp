#include <iostream>
#include <memory>
#include <string>
#include <thread>
#include <grcpp/grcpp.h>
#include "rpc_example.grpc.pb.h"

class RPCServiceImpl final : public RPCService::Service {
public:
    grpc::Status CallServer(grpc::ServerContext* context, const Request* request, Response* response) override {
        std::string client_message = request->message();
        std::string server_response = "Received message from client: " + client_message;

        response->set_message(server_response);

        return grpc::Status::OK;
    }
};

void RunServer() {
    std::string server_address("0.0.0.0:50051");
    RPCServiceImpl service;

    grpc::ServerBuilder builder;
    builder.AddListeningPort(server_address, grpc::InsecureServerCredentials());
    builder.RegisterService(&service);

    std::unique_ptr<grpc::Server> server(builder.BuildAndStart());
    std::cout << "Server listening on " << server_address << std::endl;

    server->Wait();
}

int main() {
    std::thread server_thread(RunServer);
    server_thread.join();
    return 0;
}

