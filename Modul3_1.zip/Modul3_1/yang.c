#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <pthread.h>  

#define baris 8
#define kolom 8

int faktorial(int n) {
    if (n <= 1)
        return 1;
    return n * faktorial(n - 1);
}

typedef struct {
    int (*matriks)[kolom];
    int (*matriksTranspose)[baris];
    int baris_start;
    int baris_end;
} ThreadData;

void *TransposeNFaktorial(void *arg) {
    ThreadData *data = (ThreadData *)arg;

    for (int i = data->baris_start; i < data->baris_end; i++) {
        for (int j = 0; j < kolom; j++) {
            data->matriksTranspose[j][i] = data->matriks[i][j];
            data->matriks[i][j] = faktorial(data->matriksTranspose[j][i]);
        }
    }

    pthread_exit(NULL);
}

int main() {
    int shmid;
    key_t key = ftok(".", 'A'); 

    shmid = shmget(key, sizeof(int[kolom][baris]), 0);  
    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }

    int (*matriks)[baris] = shmat(shmid, 0, 0);
    if (matriks == (int(*)[baris])-1) {
        perror("shmat");
        exit(1);
    }

    int matriksTranspose[kolom][baris];

    printf("\n Matriks hasil pengurangan 1 : \n");
    for (int i = 0; i < baris; i++) {
        for (int j = 0; j < kolom; j++) {
            printf("%d ", matriks[i][j]);
        }
        printf("\n");
    }

    pthread_t threads[baris];
    ThreadData threadData[baris];

    for (int i = 0; i < baris; i++) {
        threadData[i].matriks = matriks;
        threadData[i].matriksTranspose = matriksTranspose;
        threadData[i].baris_start = i;
        threadData[i].baris_end = i + 1;
        pthread_create(&threads[i], NULL, TransposeNFaktorial, &threadData[i]);
    }

    for (int i = 0; i < baris; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("\n Matriks yang telah ditranspose :\n");
    for (int i = 0; i < kolom; i++) {
        for (int j = 0; j < baris; j++) {
            printf("%d ", matriksTranspose[i][j]);
        }
        printf("\n");
    }

    printf("\n Nilai faktorial matriks: \n");
    for (int i = 0; i < baris; i++) {
        for (int j = 0; j < kolom; j++) {
            printf("%d ", matriks[i][j]);
        }
        printf("\n");
    }

    shmdt(matriks);

    return 0;
}
