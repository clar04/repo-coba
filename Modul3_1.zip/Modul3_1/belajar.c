#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define baris1 8
#define kolom1 2
#define baris2 2
#define kolom2 8

int main() {
    srand(time(0));

    int shmid;
    key_t key = ftok(".", 'A');

    shmid = shmget(key, sizeof(int[baris1][kolom2]), IPC_CREAT | 0666);
    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }

    int (*hasil_akhir)[kolom2] = shmat(shmid, 0, 0);
    if (hasil_akhir == (int(*)[kolom2])-1) {
        perror("shmat");
        exit(1);
    }

    int num_baris1 = baris1;
    int num_kolom1 = kolom1;
    int num_baris2 = baris2;
    int num_kolom2 = kolom2;

    int matriks1[num_baris1][num_kolom1];
    for (int i = 0; i < num_baris1; i++) {
        for (int j = 0; j < num_kolom1; j++) {
            matriks1[i][j] = rand() % 4 + 1;
        }
    }

    int matriks2[num_baris2][num_kolom2];
    for (int i = 0; i < num_baris2; i++) {
        for (int j = 0; j < num_kolom2; j++) {
            matriks2[i][j] = rand() % 5 + 1;
        }
    }

    printf("Matriks Pertama :\n");
    for (int i = 0; i < num_baris1; i++) {
        for (int j = 0; j < num_kolom1; j++) {
            printf("%d ", matriks1[i][j]);
        }
        printf("\n");
    }

    printf("\nMatriks Kedua :\n");
    for (int i = 0; i < num_baris2; i++) {
        for (int j = 0; j < num_kolom2; j++) {
            printf("%d ", matriks2[i][j]);
        }
        printf("\n");
    }

    if (num_kolom1 != num_baris2) {
        printf("\nPerkalian matriks tidak memungkinkan.");
        return 1; 
    } else {
       
        int hasil[num_baris1][num_kolom2];
        for (int i = 0; i < num_baris1; i++) {
            for (int j = 0; j < num_kolom2; j++) {
                hasil[i][j] = 0;
                for (int k = 0; k < num_kolom1; k++) {
                    hasil[i][j] += matriks1[i][k] * matriks2[k][j];
                }
            }
        }

        printf("\n Hasil Perkalian Matriks :\n");
        for (int i = 0; i < num_baris1; i++) {
            for (int j = 0; j < num_kolom2; j++) {
                printf("%d ", hasil[i][j]);
            }
            printf("\n");
        }

        for (int i = 0; i < num_baris1; i++) {
            for (int j = 0; j < num_kolom2; j++) {
                hasil_akhir[i][j] = hasil[i][j] - 1;
            }
        }
       
        printf("\n Hasil Perkalian Matriks Setelah Dikurangi 1 :\n");
        for (int i = 0; i < num_baris1; i++) {
            for (int j = 0; j < num_kolom2; j++) {
                printf("%d ", hasil_akhir[i][j]);
            }
            printf("\n");
        }
    }

    shmdt(hasil_akhir);

    return 0;
}





