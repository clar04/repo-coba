#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <math.h>

#define kolom 8
#define baris 8

int faktorial(int n) {
    if (n <= 1)
        return 1;
    return n * faktorial(n - 1);
}

int main() {
    key_t key = ftok(".", 'A');  
    int shmid = shmget(key, sizeof(int[kolom][baris]), 0);  
    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }

    int (*matriks)[baris] = shmat(shmid, 0, 0);
    if (matriks == (int(*)[baris])-1) {
        perror("shmat");
        exit(1);
    }

    int matriksTranspose[kolom][baris];

    printf("\n Matriks hasil pengurangan 1 : \n");
    for (int i = 0; i < baris; i++) {
        for (int j = 0; j < kolom; j++) {
            printf("%d ", matriks[i][j]);
        }
        printf("\n");
    }

    for (int i = 0; i < baris; i++) {
        for (int j = 0; j < kolom; j++) {
            matriksTranspose[j][i] = matriks[i][j];
            matriks[i][j] = faktorial(matriksTranspose[j][i]);
        }
    }

    printf("\n Matriks yang telah ditranspose :\n");
    for (int i = 0; i < kolom; i++) {
        for (int j = 0; j < baris; j++) {
            printf("%d ", matriksTranspose[i][j]);
        }
        printf("\n");
    }

    printf("\n Nilai faktorial matriks: \n");
    for (int i = 0; i < baris; i++) {
        for (int j = 0; j < kolom; j++) {
            printf("%d ", matriks[i][j]);
        }
        printf("\n");
    }

    shmdt(matriks);

    return 0;
}
